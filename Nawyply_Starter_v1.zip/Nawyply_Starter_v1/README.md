# Nawyply v1.0 — starter Android

Fondasi antarmuka Nawyply berbasis web yang dapat dibungkus menjadi APK Android menggunakan Capacitor.

## Yang sudah ada pada prototipe
- Antarmuka responsif dengan gaya Liquid Glass.
- Navigasi Chat, Grup, Premium, Setelan, dan Admin.
- Chat demo lokal; pesan dan tema disimpan di `localStorage`.
- Service worker untuk cache aset agar tampilan dapat dibuka offline setelah kunjungan pertama.
- Pengaturan warna aksen, gelembung, dan latar.

## Yang BELUM aktif
Ini belum merupakan layanan messenger online produksi. Chat yang dibuat saat ini hanya tersimpan pada perangkat dan tidak terkirim ke orang lain. Tombol Google, blokir admin, grup, dan premium masih berupa pratinjau.
Untuk mengaktifkan layanan sungguhan diperlukan:
1. Proyek Firebase milik pemilik aplikasi.
2. Firebase Authentication (Google) + konfigurasi OAuth Android (package `com.nawyply.app` dan SHA-1/SHA-256).
3. Cloud Firestore atau backend pesan dengan aturan keamanan, validasi server, dan sinkronisasi offline.
4. Sistem peran admin yang ditetapkan server; jangan mempercayai status admin dari aplikasi.
5. Kebijakan pembatasan tiga akun yang ditegakkan server berdasarkan identitas terverifikasi/perangkat sesuai kebijakan privasi.
6. Penyedia pembayaran dan konfigurasi langganan Google Play Billing untuk distribusi Play Store.

## Membuat APK di komputer
Persyaratan: Node.js LTS, Android Studio, Android SDK, dan JDK yang didukung Android Gradle Plugin.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK debug biasanya berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

Jika folder `android` sudah pernah dibuat, jangan jalankan `npx cap add android` lagi; cukup `npm run build` lalu `npx cap sync android`.

## Menjalankan pratinjau
```bash
npm install
npm run start
```

## Catatan offline
Service worker menyimpan aset antarmuka setelah aplikasi dibuka pertama kali. `localStorage` menyimpan percakapan demo. Sinkronisasi pesan antarperangkat memerlukan backend dan belum diimplementasikan.


## Build APK hanya dengan HP (GitHub Actions)
1. Buat repository GitHub baru.
2. Upload file `Nawyply_Starter_v1.zip` ke repository (jangan diekstrak).
3. Di repository, pilih **Add file > Create new file**.
4. Nama file: `.github/workflows/build-apk.yml`.
5. Tempel isi file workflow `nawyply-build-apk.yml` yang disediakan terpisah, lalu commit.
6. Buka tab **Actions**, pilih **Build Nawyply Android APK**, lalu tekan **Run workflow**.
7. Setelah selesai, buka hasil run dan unduh artifact `Nawyply-debug-APK` (file ZIP berisi APK). Ekstrak di HP, lalu pasang `app-debug.apk`.

Catatan: workflow ini menghasilkan APK debug prototipe. Google login, chat lintas perangkat, admin server, dan pembayaran belum aktif sampai backend dan kredensial layanan disiapkan.
