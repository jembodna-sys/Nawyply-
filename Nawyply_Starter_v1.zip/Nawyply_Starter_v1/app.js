const $ = (s) => document.querySelector(s);
const seed = [
 {id:"a",name:"Alya",initial:"A",preview:"Hai! Selamat datang di Nawyply 👋",time:"09.41",messages:[{text:"Hai! Selamat datang di Nawyply 👋",mine:false,time:"09.41"},{text:"Terima kasih! Ini masih versi demo ya.",mine:true,time:"09.42"}]},
 {id:"b",name:"Ruang Santai",initial:"R",preview:"Belum ada pesan baru",time:"Kemarin",messages:[]},
 {id:"c",name:"Dimas",initial:"D",preview:"Coba tema Liquid Glass-nya!",time:"Senin",messages:[{text:"Coba tema Liquid Glass-nya!",mine:false,time:"Senin"}]}
];
let chats = JSON.parse(localStorage.getItem("nawyply_chats") || "null") || seed;
let active = null;
let groups = JSON.parse(localStorage.getItem("nawyply_groups") || "[]");
let blocked = JSON.parse(localStorage.getItem("nawyply_blocked") || "[]");
function save(){localStorage.setItem("nawyply_chats",JSON.stringify(chats));}
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300);}
function renderChats(){
 $("#chatList").innerHTML=chats.map(c=>`<div class="chat-item" data-id="${c.id}"><div class="person-avatar">${esc(c.initial)}</div><div class="chat-meta"><b>${esc(c.name)}</b><p>${esc(c.preview||"Belum ada pesan")}</p></div><span class="chat-time">${esc(c.time||"")}</span></div>`).join("");
 document.querySelectorAll(".chat-item").forEach(el=>el.addEventListener("click",()=>openChat(el.dataset.id)));
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function openChat(id){active=chats.find(c=>c.id===id);if(!active)return;$("#contactName").textContent=active.name;$("#contactAvatar").textContent=active.initial;renderMessages();$("#chatDialog").showModal();}
function renderMessages(){const box=$("#messages");box.innerHTML=active.messages.map(m=>`<div class="bubble ${m.mine?"mine":""}">${esc(m.text)}<small>${esc(m.time)}</small></div>`).join("");box.scrollTop=box.scrollHeight;}
$("#sendForm").addEventListener("submit",e=>{e.preventDefault();const text=$("#messageInput").value.trim();if(!text||!active)return;const time=new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"});active.messages.push({text,mine:true,time});active.preview=text;active.time=time;save();$("#messageInput").value="";renderMessages();renderChats();});
$("#closeChat").onclick=()=>$("#chatDialog").close();
$("#chatMenu").onclick=()=>toast("Opsi chat akan tersedia pada versi berikutnya.");
$("#newChat").onclick=()=>{const name=prompt("Nama kontak demo:");if(!name)return;const id="c"+Date.now();chats.unshift({id,name,initial:name[0].toUpperCase(),preview:"Mulai percakapan baru",time:"Baru",messages:[]});save();renderChats();toast("Chat demo dibuat.");};
function setTab(tab){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));$("#chatList").classList.toggle("hidden",tab!=="chats");["groups","premium","settings","admin"].forEach(x=>$("#"+x+"Panel").classList.toggle("hidden",tab!==x));$("#sectionTitle").textContent=({chats:"Obrolan",groups:"Grup",premium:"Premium",settings:"Setelan",admin:"Admin"})[tab];$("#sectionEyebrow").textContent=({chats:"PESAN TERBARU",groups:"KOMUNITAS",premium:"NAW YPLY PLUS",settings:"TAMPILAN",admin:"PENGELOLAAN"})[tab];}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
function renderGroups(){$("#groupItems").innerHTML=groups.map(g=>`<div class="chat-item" style="margin-top:9px"><div class="person-avatar">#</div><div class="chat-meta"><b>${esc(g)}</b><p>Grup demo lokal</p></div></div>`).join("");}
$("#createGroup").onclick=()=>{const n=prompt("Nama grup:");if(n){groups.push(n);localStorage.setItem("nawyply_groups",JSON.stringify(groups));renderGroups();toast("Grup demo dibuat.");}};
$("#googleBtn").onclick=()=>toast("Login Google memerlukan Firebase + OAuth milik pemilik aplikasi.");
$("#profileBtn").onclick=()=>toast("Profil akun akan aktif setelah login Google dikonfigurasi.");
$("#premiumBtn").onclick=()=>toast("Pembayaran premium belum diaktifkan.");
$("#themeBtn").onclick=()=>{document.body.classList.toggle("midnight");toast("Mode tampilan diubah.");};
$("#saveTheme").onclick=()=>{document.documentElement.style.setProperty("--accent",$("#accent").value);document.documentElement.style.setProperty("--bubble",$("#bubble").value);document.body.classList.remove("ocean","midnight");document.body.classList.add($("#wallpaper").value);localStorage.setItem("nawyply_theme",JSON.stringify({accent:$("#accent").value,bubble:$("#bubble").value,wallpaper:$("#wallpaper").value}));toast("Tema tersimpan di perangkat.");};
const saved=JSON.parse(localStorage.getItem("nawyply_theme")||"null");if(saved){$("#accent").value=saved.accent;$("#bubble").value=saved.bubble;$("#wallpaper").value=saved.wallpaper;document.documentElement.style.setProperty("--accent",saved.accent);document.documentElement.style.setProperty("--bubble",saved.bubble);document.body.classList.add(saved.wallpaper);}
$("#blockBtn").onclick=()=>{const n=$("#blockName").value.trim();if(!n)return toast("Masukkan nama pengguna.");blocked.push(n);localStorage.setItem("nawyply_blocked",JSON.stringify(blocked));renderBlocked();$("#blockName").value="";toast("Pengguna ditandai blokir pada demo lokal.");};
function renderBlocked(){$("#blockedList").innerHTML=blocked.length?`<p class="muted">Daftar blokir demo: ${blocked.map(esc).join(", ")}</p>`:"";}
renderChats();renderGroups();renderBlocked();
function network(){const online=navigator.onLine;$("#connection").innerHTML=`<i style="background:${online?"#61d6a2":"#e6a85b"}"></i> ${online?"Online • sinkronisasi server belum diatur":"Offline • mode lokal aktif"}`;}
window.addEventListener("online",network);window.addEventListener("offline",network);network();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
